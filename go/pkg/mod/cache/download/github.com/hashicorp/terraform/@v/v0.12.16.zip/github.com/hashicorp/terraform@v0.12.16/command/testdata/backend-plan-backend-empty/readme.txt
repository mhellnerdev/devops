This directory is empty on purpose.
