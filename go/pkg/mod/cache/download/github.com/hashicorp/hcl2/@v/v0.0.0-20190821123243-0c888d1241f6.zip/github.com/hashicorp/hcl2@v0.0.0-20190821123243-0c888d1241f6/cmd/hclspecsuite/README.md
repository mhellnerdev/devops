# `hclspecsuite`

`hclspecsuite` is the test harness for
[the HCL specification test suite](../../specsuite/README.md).
